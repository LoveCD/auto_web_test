---
name: test-case-generator
description: >-
  根据源码函数签名、逻辑分支和依赖关系自动生成单元测试用例。
  覆盖正常路径、边界条件、异常输入和并发场景。支持 Jest、Vitest、Mocha、pytest、Go testing。
  Use when generating unit test cases from source code — extracts function signatures,
  analyzes branches, and produces runnable test files with mocks and assertions.
version: 1.1.0
metadata:
  category: testing
  tags:
    - unit-test
    - test-generation
    - jest
    - pytest
    - mocha
    - go
---

# Test Case Generator

根据源码自动生成结构化、可运行的单元测试用例。

## 核心方法论

### 1. 等价类划分（Equivalence Partitioning）

将输入域划分为若干等价类，每类取一个代表值：

```
输入: 用户年龄（1-120 整数）
  有效等价类: 1-120
  无效等价类: <1, >120, 非数字, 空, 负数
  边界值: 0, 1, 120, 121
```

### 2. 边界值分析（Boundary Value Analysis）

对每个边界取「左边界、边界值、右边界」：

```
规则: password length 8-63
  7  (边界外，应拒绝)
  8  (边界内，应通过)
  63 (边界内，应通过)
  64 (边界外，应拒绝)
  空 (边界外，应拒绝)
```

### 3. 决策表测试（Decision Table）

多条件组合时使用决策表确保全覆盖：

```
条件: isVIP x hasCoupon
  T, T -> 折扣叠加，最高 50%
  T, F -> VIP 9 折
  F, T -> 优惠券折扣
  F, F -> 原价
```

### 4. 分支覆盖（Branch Coverage）

分析函数中每个 if/else/switch/try-catch 分支，确保每条路径至少一个用例。

## 生成流程

1. **提取函数签名**：参数类型、返回类型、异常声明
2. **分析逻辑分支**：if/else、switch、循环、try-catch、提前 return
3. **识别依赖**：外部 API、数据库、文件系统、时间、随机数
4. **划分等价类**：按参数类型和业务规则划分
5. **选取边界值**：对每个边界取左/中/右
6. **生成 Mock**：对外部依赖生成 mock/stub
7. **输出测试文件**：含 import、fixture、setup/teardown、断言

## 用例优先级

| 优先级 | 覆盖范围 | 说明 |
|--------|----------|------|
| P0 | 正常路径 | 核心功能的主流程，必须通过 |
| P0 | 关键边界 | 空值、零值、最大值、最小值 |
| P1 | 异常路径 | 非法输入、权限不足、资源不存在 |
| P1 | 分支覆盖 | 每个 if/else 分支至少一个用例 |
| P2 | 边角组合 | 多参数组合、并发、性能边界 |

## 框架模板

### Jest / Vitest (JavaScript/TypeScript)

```javascript
import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { calculateDiscount } from './pricing.js';

describe('calculateDiscount', () => {
  // P0: 正常路径
  test('returns 0 when no discount applicable', () => {
    expect(calculateDiscount(100, { isVIP: false, hasCoupon: false })).toBe(0);
  });

  test('applies VIP discount correctly', () => {
    expect(calculateDiscount(100, { isVIP: true, hasCoupon: false })).toBe(10);
  });

  // P0: 边界值
  test('handles zero price', () => {
    expect(calculateDiscount(0, { isVIP: true, hasCoupon: true })).toBe(0);
  });

  // P1: 异常路径
  test('throws on negative price', () => {
    expect(() => calculateDiscount(-50, { isVIP: false, hasCoupon: false }))
      .toThrow('price must be non-negative');
  });

  // P1: 边界组合
  test('caps combined discount at 50%', () => {
    expect(calculateDiscount(1000, { isVIP: true, hasCoupon: true })).toBe(500);
  });
});
```

### pytest (Python)

```python
import pytest
from pricing import calculate_discount


class TestCalculateDiscount:
    """P0: 正常路径"""

    def test_no_discount_when_no_flags(self):
        assert calculate_discount(100, is_vip=False, has_coupon=False) == 0

    def test_vip_discount_applied(self):
        assert calculate_discount(100, is_vip=True, has_coupon=False) == 10

    """P0: 边界值"""

    def test_zero_price(self):
        assert calculate_discount(0, is_vip=True, has_coupon=True) == 0

    """P1: 异常路径"""

    def test_negative_price_raises(self):
        with pytest.raises(ValueError, match="price must be non-negative"):
            calculate_discount(-50, is_vip=False, has_coupon=False)

    """P1: 边界组合"""

    def test_combined_discount_capped(self):
        assert calculate_discount(1000, is_vip=True, has_coupon=True) == 500


# 参数化测试：批量覆盖等价类
@pytest.mark.parametrize("price,is_vip,has_coupon,expected", [
    (100, False, False, 0),       # 正常路径
    (100, True, False, 10),       # VIP 折扣
    (100, False, True, 15),       # 优惠券折扣
    (100, True, True, 50),        # 组合折扣
    (0, True, True, 0),           # 边界值: 零价格
    (-1, False, False, None),     # 异常路径
])
def test_calculate_discount_matrix(price, is_vip, has_coupon, expected):
    if expected is None:
        with pytest.raises(ValueError):
            calculate_discount(price, is_vip, has_coupon)
    else:
        assert calculate_discount(price, is_vip, has_coupon) == expected
```

### Go testing

```go
func TestCalculateDiscount(t *testing.T) {
    tests := []struct {
        name      string
        price     float64
        isVIP     bool
        hasCoupon bool
        expected  float64
        wantErr   bool
    }{
        // P0: 正常路径
        {"no discount", 100, false, false, 0, false},
        {"VIP only", 100, true, false, 10, false},
        // P0: 边界值
        {"zero price", 0, true, true, 0, false},
        // P1: 异常路径
        {"negative price", -50, false, false, 0, true},
        // P1: 边界组合
        {"capped at 50%", 1000, true, true, 500, false},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            result, err := CalculateDiscount(tt.price, tt.isVIP, tt.hasCoupon)
            if tt.wantErr {
                if err == nil {
                    t.Errorf("expected error, got nil")
                }
                return
            }
            if err != nil {
                t.Fatalf("unexpected error: %v", err)
            }
            if result != tt.expected {
                t.Errorf("got %v, want %v", result, tt.expected)
            }
        })
    }
}
```

## Mock 策略

### 原则

- **Mock 外部依赖，不 Mock 被测代码**
- 优先 Mock：数据库、HTTP API、文件系统、时间、随机数
- 不 Mock：纯函数、被测函数本身

### Jest Mock 示例

```javascript
jest.mock('./api.js');
import { getUser } from './api.js';

test('processes user data from API', async () => {
  getUser.mockResolvedValue({ id: 1, name: 'Alice', active: true });
  const result = await processUser(1);
  expect(result.processed).toBe(true);
  expect(getUser).toHaveBeenCalledWith(1);
});
```

### pytest Mock 示例

```python
from unittest.mock import patch, MagicMock

@patch('mymodule.requests.get')
def test_fetch_data(mock_get):
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = {"data": "test"}

    result = fetch_data("https://api.example.com")
    assert result == {"data": "test"}
    mock_get.assert_called_once_with("https://api.example.com")
```

## 质量检查清单

- [ ] 每个公开函数至少 3 个用例（正常、边界、异常）
- [ ] 每个 if/else 分支至少 1 个用例
- [ ] 空值、零值、最大值、最小值已覆盖
- [ ] 异常路径已覆盖（非法输入、权限不足、资源不存在）
- [ ] Mock 只用于外部依赖，未 Mock 被测代码
- [ ] 测试用例互相独立，无执行顺序依赖
- [ ] 测试名称描述行为，不描述实现
- [ ] 断言精确（检查返回值，不仅检查不报错）

## 反模式

| 反模式 | 问题 | 正确做法 |
|--------|------|----------|
| 只测正常路径 | 70% 的 bug 在边界和异常 | 每个函数至少覆盖正常、边界、异常 |
| 测试名称模糊 | test_1 无法理解意图 | test_rejects_empty_email |
| Mock 被测代码 | 测试变成自证循环 | 只 Mock 外部依赖 |
| 断言过弱 | assert result is not None | assert result == expected |
| 测试间共享状态 | 顺序依赖、flaky | 每个用例独立 setup/teardown |
